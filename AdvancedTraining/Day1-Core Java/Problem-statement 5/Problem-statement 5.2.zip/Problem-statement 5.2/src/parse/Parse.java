package parse;

public class Parse {
	 public static void main(String args[])
	    {
	        String str = "23  +  45  -  (  343  /  12  )";
	        String[] str1 = str.split("\\\s");
	 
	        for (String a : str1)
	            System.out.println(a);
	    }
}
