package palindrome;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String s;
		System.out.println("enter string name");
		s = sc.next();
			for (int i = 0; i < args.length; i++) {
				s =s+args[i];
			}
			System.out.println("The length of the string: " + s.length());
			System.out.println("The string into uppercase: " + s.toUpperCase());
			if (isPalindrome(s)) {
				System.out.println(s + " is a palindrome");
			} else {
				System.out.println(s + " is not a palindrome");
			}
		} 
	static boolean isPalindrome(String s) {
		int index = 0;
		int length = s.length()-1;
		while (length > index) {
			if (s.charAt(index) != s.charAt(length)) {
				return false;
			}
			index++;
			length--;
		}
		return true;
	}
}
