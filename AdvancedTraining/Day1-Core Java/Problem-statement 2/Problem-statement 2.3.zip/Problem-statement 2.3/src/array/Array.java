package array;
public class Array {

	public static void main(String[] args) {
		int A[] = {1, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
        System.out.println("Smallest: "+getSmallest(A,18));
		System.out.print("Array after average: {");
		for(int i=0;i<=17;i++) {
			System.out.print(A[i]+" ");
		}System.out.println("}");
}
	public static int getSmallest(int[] a, int total){
		System.out.println("the sum of elements from index 0 to 14 and stored it at element 15");
		int sum=0;
		System.out.print("Array after addition: {");
		 for(int i=0;i<=17;i++) {
			sum=sum+a[i];
			System.out.print(a[i]+" ");
			a[15]=sum;
	}
		 System.out.println("}");
		 System.out.println("sum= "+sum);
		 System.out.println("the average of all numbers and stored it at element 16");
		 int avg=0;
		 avg=sum/17;
		 System.out.println("average= "+avg);
			System.out.print("Array after average: {");
			for(int i=0;i<=17;i++) {
				
				a[16]=avg;
				System.out.print(a[i]+" ");
			}System.out.println("}");
			
			System.out.println("the smallest value from the array and stored it at element 17");
		int temp;  
		for (int i = 0; i < total; i++)   
		        {  
		            for (int j = i + total; j < 17; j++)   
		            {  
		                if (a[i] > a[j])   
		                {  
		                    temp = a[i];  
		                    a[i] = a[j];  
		                    a[j] = temp;  
		                }  
		            }
		        }  
		       a[17]=a[0];
				return a[0];
		}  }