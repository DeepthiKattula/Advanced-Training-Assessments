package even;

import java.util.Scanner;

public class Even {
public static void main(String [] args) {
	Scanner s= new Scanner(System.in);
	
	int n;
	 
	System.out.println("enter n value");
	n = s.nextInt();
	for(int i=1;i<=n;i++) {
		if(i%2==0) {
			System.out.print(i+" ");
			
		}
	}
}
}
